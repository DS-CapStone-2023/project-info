def character_count(input):
    """
    For the input string, return the total number of characters
    input: a string
    """
    return len(str(input).strip())
